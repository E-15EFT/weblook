from django.apps import AppConfig


class YoutubeDownloaderConfig(AppConfig):
    name = 'youtube_downloader'
